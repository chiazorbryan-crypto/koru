// Koru reader: long-strip (manhwa) or page-by-page (manga), with saved progress, offline pages,
// chapter drawer, auto next chapter and keyboard controls.
'use strict';
(function () {
  const { el, icon } = K;
  const DEFAULTS = { mode: 'strip', rtl: false, gap: 0, width: 760, autoNext: true, preload: 4, tapZones: true, ambient: true, ambStrength: 55, ambBlur: 90, fps: false, zen: false, autoSpeed: 90, autoSecs: 8, autoStart: false };
  K.readerSettings = () => ({ ...DEFAULTS, ...(K.data.settings.reader || {}) });
  const setReader = patch => { K.data.settings.reader = { ...K.readerSettings(), ...patch }; K.save('settings'); };

  let box = null, state = null;
  let autoKeep = false;   // auto-scroll carries on into the next chapter while it's on

  // Background worker that decodes pages and draws their slices (see slicer.js).
  let slicer = null, sliceSeq = 0;
  const waits = new Map();
  const ask = (msg, transfer) => {
    if (!slicer) {
      slicer = new Worker('js/slicer.js');
      slicer.onmessage = e => { const w = waits.get(e.data.id); if (!w) return; waits.delete(e.data.id); e.data.type === 'error' ? w.reject(new Error(e.data.error)) : w.resolve(e.data); };
    }
    return new Promise((resolve, reject) => { waits.set(msg.id, { resolve, reject }); slicer.postMessage(msg, transfer || []); });
  };
  const freeJob = id => { if (id && slicer) slicer.postMessage({ type: 'free', id }); };

  K.closeReader = function (fromRoute) {
    if (!box) return;
    saveProgress();
    state?.cleanup?.();
    const b = box; box = null; state = null;
    document.documentElement.classList.remove('reading');
    if (b.classList.contains('zen')) K.api.post('/k/fullscreen', { on: false }).catch(() => {});
    b.style.animation = 'fade-out var(--t-fast) both';
    setTimeout(() => b.remove(), 180);
    if (!fromRoute) K.back();
  };

  function saveProgress() {
    if (!state?.chapter || !state.pages?.length || K.incognito() || K.flag(state.provider, state.slug).trash) return;
    const { provider, slug, series } = state;
    const loc = state.local?.() || { chapter: state.chapter, page: state.page, total: state.pages.length };
    const chapter = loc.chapter;
    const k = K.key(provider, slug);
    K.data.history[k] = { provider, slug, title: series?.title || slug, cover: series?.cover || K.data.history[k]?.cover,
      chapterSlug: chapter.slug, chapterName: chapter.name.replace(/ — .*/, ''), page: loc.page, off: state.where?.() || 0,
      done: !!state.finished, total: loc.total, at: Date.now() };
    K.save('history');
    if (state.finished || loc.page >= loc.total - 1) K.finishChapter?.(chapter);
  }

  K.openReader = async function (provider, slug, chapterSlug) {
    const opt = K.readerSettings();
    const first = !box;
    if (first) {
      box = el('div.reader');
      document.body.append(box);
      document.documentElement.classList.add('reading');
    } else { saveProgress(); state?.cleanup?.(); }
    const my = state = { provider, slug, chapterSlug, page: 0, pages: [] };
    box.className = 'reader' + (opt.mode === 'paged' ? ' paged' : '');
    box.replaceChildren(el('div.spinner', { style: { marginTop: '40vh' } }));

    // Series + chapter list (falls back to downloads when offline).
    let series = null, chapters = [];
    try { series = await K.getSeries(provider, slug); chapters = await K.getChapters(provider, slug); }
    catch {
      const d = K.dl.series?.find(x => x.provider === provider && x.seriesSlug === slug);
      if (d) { series = { title: d.title, cover: d.cover }; chapters = d.chapters.map(c => ({ slug: c.chapterSlug, name: c.chapterName, number: c.number, locked: false })).sort((a, b) => (b.number ?? 0) - (a.number ?? 0)); }
    }
    if (my !== state) return;
    const idx = chapters.findIndex(c => c.slug === chapterSlug);
    const chapter = chapters[idx] || { slug: chapterSlug, name: chapterSlug.replace(/-/g, ' ') };
    const newer = idx > 0 ? chapters.slice(0, idx).reverse().find(c => !c.locked) : null;   // next chapter
    const older = idx >= 0 ? chapters.slice(idx + 1).find(c => !c.locked) : null;           // previous chapter
    Object.assign(state, { series, chapters, chapter, next: newer, prev: older });

    // Pages: downloaded copy first, then the site.
    const id = `${provider}:${slug}:${chapterSlug}`;
    let pages = K.localPages(id), offline = !!pages;
    if (!pages) {
      try { pages = await K.providers[provider].pages(slug, chapterSlug); }
      catch (e) {
        if (my !== state) return;
        box.replaceChildren(topBar(), el('div.empty', { style: { marginTop: '18vh' } }, K.fox(), el('h3', { text: e.locked ? 'This chapter is locked' : 'Couldn\'t open this chapter' }),
          el('p', { text: e.locked ? 'It\'s paid or early access on the site. Koru only reads free chapters.' : e.message }),
          el('div.row', { style: { justifyContent: 'center' } }, newer ? el('button.btn.primary', { onclick: () => goChapter(newer) }, 'Next chapter', icon('next')) : null,
            el('button.btn', { onclick: () => K.closeReader() }, icon('back'), 'Back'))));
        return;
      }
    }
    if (my !== state) return;
    state.pages = pages;
    const hist = K.data.history[K.key(provider, slug)];
    const askPage = Number(new URLSearchParams(location.hash.split('?')[1] || '').get('page'));
    const resume = hist?.chapterSlug === chapterSlug && !hist.done && hist.page < pages.length && (hist.off > 0 || hist.page < pages.length - 1);
    const startPage = askPage > 0 && askPage < pages.length ? askPage : resume ? hist.page : 0;
    const startOff = !(askPage > 0) && resume ? Math.max(0, Math.min(0.999, hist.off || 0)) : 0;
    build(offline, startPage, startOff);
  };

  function goChapter(c) { K.go(`/read/${state.provider}/${encodeURIComponent(state.slug)}/${encodeURIComponent(c.slug)}`, true); }

  const localPage = () => state?.local ? state.local().page : state?.page;
  const markId = () => `${state.provider}:${state.slug}:${state.chapter?.slug}:${localPage()}`;
  function paintMark() {
    const b = box?.querySelector('.markb');
    if (b && state) b.classList.toggle('on', !!K.data.bookmarks[markId()]);
  }
  K.paintMark = paintMark;
  function topBar() {
    const s = state;
    const mark = el('button.btn.icon.markb', { title: 'Bookmark this page', onclick: () => {
      const id = markId();
      if (K.data.bookmarks[id]) { delete K.data.bookmarks[id]; K.toast('Bookmark removed'); }
      else {
        K.data.bookmarks[id] = { id, provider: s.provider, slug: s.slug, title: s.series?.title || s.slug, cover: s.series?.cover || null,
          chapterSlug: s.chapter.slug, chapterName: s.chapter.name.replace(/ — .*/, ''), page: localPage(), at: Date.now() };
        K.toast(`Page ${localPage() + 1} bookmarked`, 'ok');
      }
      K.save('bookmarks'); paintMark();
    } }, icon('bookmark'));
    return el('div.rbar.top.glass',
      el('button.btn.icon', { title: 'Back', onclick: () => K.closeReader() }, icon('back')),
      el('div.tt', el('b', { text: s.series?.title || s.slug }), el('small', { text: s.chapter?.name || '' })),
      K.incognito() ? el('span.tag', { title: 'Nothing is saved while incognito' }, 'Incognito') : null,
      s.pages?.length ? mark : null,
      el('button.btn.icon.autob', { title: 'Auto-scroll (S)', onclick: () => K.toggleAuto?.() }, icon('auto')),
      el('button.btn.icon', { title: 'Zen mode (Z)', onclick: () => K.toggleZen?.() }, icon('zen')),
      el('button.btn.icon', { title: 'Chapters', onclick: () => box.querySelector('.drawer')?.classList.toggle('open') }, icon('list')));
  }

  function build(offline, startPage, startOff = 0) {
    const s = state, opt = K.readerSettings();
    // Ambient light: a tiny pre-blurred picture of the page, stretched up. No live blur filter, so scrolling never redoes it.
    const AW = 40, AH = 26;
    const amb = el('div.ambient', el('canvas', { width: AW, height: AH }), el('canvas', { width: AW, height: AH }));
    let ambFront = 0, ambIdx = -1, ambBmp = null, ambSoft = opt.ambBlur;
    const ambCache = new Map();   // page -> tiny picture, made once when the page loads
    const paintAmb = () => {
      if (!ambBmp) return;
      const [a, b] = amb.children, next = ambFront ? a : b, cur = ambFront ? b : a;
      const ctx = next.getContext('2d');
      ctx.clearRect(0, 0, AW, AH);
      ctx.filter = `blur(${(ambSoft / 40).toFixed(1)}px) saturate(1.8)`;
      ctx.drawImage(ambBmp, -2, -2, AW + 4, AH + 4);
      next.classList.add('on'); cur.classList.remove('on'); ambFront = ambFront ? 0 : 1;
    };
    const applyAmb = o => { amb.style.display = o.ambient ? '' : 'none'; amb.style.setProperty('--amb-o', o.ambStrength / 100); if (o.ambBlur !== ambSoft) { ambSoft = o.ambBlur; paintAmb(); } };
    applyAmb(opt);
    const setAmb = K.debounce(i => {
      if (i === ambIdx || amb.style.display === 'none') return;
      const bmp = ambCache.get(i);
      if (!bmp) return;            // painted as soon as that page loads
      ambIdx = i; ambBmp = bmp; paintAmb();
    }, 200);

    const pagesBox = el('div.pages', { tabIndex: 0 });
    const strip = el('div.strip', { style: { maxWidth: opt.mode === 'strip' ? opt.width + 'px' : 'none', gap: opt.gap + 'px' } });
    pagesBox.append(strip);

    // Long strip: each page is fetched as a file, decoded off the main thread and cut into short slices.
    // The graphics card then only moves ready-made pieces while you scroll, instead of re-decoding giant
    // pictures (some pages are 900×16000) over and over, which is what lagged on big screens.
    const SLICE = 1536, OV = 2;
    const st = s.pages.map(() => '');   // '', 'loading', 'ready'
    const files = new Map();            // page -> downloaded file, kept for this chapter so scrolling back is instant
    const job = s.pages.map(() => '');  // current worker job per page
    const freeSlices = wrap => {
      const i = Number(wrap.dataset.i);
      freeJob(job[i]); job[i] = '';
      wrap.querySelector('.slices')?.remove(); wrap.classList.remove('sliced');
    };
    const fileOf = async i => {
      if (files.has(i)) return files.get(i);
      const url = s.pages[i].url;
      const u = /^(\/|koru:)/.test(url) ? url : '/k/fetch?u=' + encodeURIComponent(url) + '&accept=' + encodeURIComponent('image/avif,image/webp,image/*;q=0.8');
      const r = await fetch(u);
      if (!r.ok) throw new Error('Page answered ' + r.status);
      const b = await r.blob();
      files.set(i, b);
      return b;
    };
    const failed = i => { const ph = imgs[i].nextSibling; ph.textContent = 'Page didn\'t load · tap to retry'; ph.style.fontSize = '14px'; ph.style.cursor = 'pointer'; };
    const ambFrom = (i, src, w, h) => {
      if (ambCache.has(i) || !w) return;
      ambCache.set(i, null);
      const sh = Math.min(h, Math.round(w * AH / AW)), sy = Math.round((h - sh) / 2);
      createImageBitmap(src, 0, sy, w, sh, { resizeWidth: AW, resizeHeight: AH, resizeQuality: 'low' })
        .then(b => { ambCache.set(i, b); if (s.page === i) setAmb(i); }).catch(() => ambCache.delete(i));
    };
    async function loadStrip(i) {
      const wrap = imgs[i].parentElement;
      const id = 'p' + (++sliceSeq);
      job[i] = id;
      const live = () => st[i] === 'loading' && job[i] === id;
      try {
        const file = await fileOf(i);
        if (!live()) return;
        const r = await ask({ type: 'decode', id, blob: file, aw: AW, ah: AH });   // decoded on the worker
        if (!live()) { r.amb?.close(); freeJob(id); return; }
        wrap.style.minHeight = ''; wrap.style.aspectRatio = `${r.w} / ${r.h}`;
        if (jump && i <= jump.i) requestAnimationFrame(doJump);
        if (!ambCache.get(i)) { ambCache.set(i, r.amb); if (s.page === i) setAmb(i); } else r.amb?.close();
        const box = el('div.slices'), ocs = [];
        for (let y = 0; y < r.h; y += SLICE) {
          const c = el('canvas', { width: r.w, height: Math.min(SLICE + OV, r.h - y) });
          // slices overlap by a couple of pixels so no hairline shows between them
          if (y + SLICE < r.h) c.style.marginBottom = `-${(OV / r.w) * 100}%`;
          box.append(c);
          ocs.push(c.transferControlToOffscreen());
        }
        wrap.append(box); wrap.classList.add('sliced');
        await ask({ type: 'draw', id, canvases: ocs, slice: SLICE }, ocs);              // drawn by the worker, straight to the screen
        if (live()) st[i] = 'ready';
      } catch { if (live()) { st[i] = ''; freeSlices(wrap); failed(i); } }
    }
    const addPage = (p, i) => {
      const im = el('img', { alt: `Page ${i + 1}`, decoding: 'async', referrerPolicy: 'no-referrer', draggable: false });
      im.dataset.src = p.url;
      // page mode shows the picture directly
      im.addEventListener('load', () => {
        if (st[i] !== 'loading') return;
        wrap.style.minHeight = ''; wrap.style.aspectRatio = '';
        ambFrom(i, im, im.naturalWidth, im.naturalHeight);
        im.classList.add('ready'); st[i] = 'ready';
      });
      im.addEventListener('error', () => { if (!im.getAttribute('src') || st[i] !== 'loading') return; st[i] = ''; failed(i); });
      const ph = el('div.ph', { text: String(i + 1) });
      ph.onclick = () => { if (st[i]) return; ph.textContent = String(i + 1); ph.style.fontSize = ''; ph.style.cursor = ''; files.delete(i); load(i); };
      const wrap = el('div.pg', { dataset: { i } }, im, ph);
      if (p.w && p.h) wrap.style.aspectRatio = `${p.w} / ${p.h}`; else wrap.style.minHeight = '70vh';
      return im;
    };
    const imgs = s.pages.map((p, i) => { const im = addPage(p, i); strip.append(im.parentElement); return im; });
    const pg = i => imgs[i]?.parentElement;
    const load = i => {
      const im = imgs[i];
      if (!im || st[i]) return;
      st[i] = 'loading';
      if (opt.mode === 'strip') loadStrip(i); else im.src = im.dataset.src;
    };
    // far-away pages are let go; their space stays so nothing jumps
    const unload = i => {
      const im = imgs[i];
      if (!im || !st[i] || i === s.page) return;
      st[i] = '';
      im.classList.remove('ready'); im.removeAttribute('src');
      freeSlices(im.parentElement);
    };

    // Chapters in this strip. With "Keep reading into the next chapter" on, the next free chapter is added
    // underneath as you near the end, so you just keep scrolling; the title, page count and history follow along.
    const seamless = opt.mode === 'strip' && opt.autoNext;
    const segs = [{ chapter: s.chapter, start: 0, count: s.pages.length }];
    const segOf = i => { for (let k = segs.length - 1; k >= 0; k--) if (i >= segs[k].start) return segs[k]; return segs[0]; };
    const nextAfter = ch => { const i = s.chapters.findIndex(c => c.slug === ch.slug); return i > 0 ? s.chapters.slice(0, i).reverse().find(c => !c.locked) : null; };
    const prevBefore = ch => { const i = s.chapters.findIndex(c => c.slug === ch.slug); return i >= 0 ? s.chapters.slice(i + 1).find(c => !c.locked) : null; };
    s.local = () => { const g = segOf(s.page); return { chapter: g.chapter, page: s.page - g.start, total: g.count }; };
    let appending = false, appendErr = null;
    const short = n => String(n || '').replace(/ — .*/, '');
    // the chapter you finished: read mark + Stats, once
    K.finishChapter = ch => {
      if (!ch || K.incognito() || K.flag(s.provider, s.slug).trash) return;
      if (!K.isRead(s.provider, s.slug, ch.slug)) { K.stats.chapter({ ...s, chapter: ch }); K.markRead(s.provider, s.slug, ch.slug, true); }
    };
    const end = el('div.endcard.glass');
    function paintEnd() {
      const last = segs[segs.length - 1].chapter, nx = nextAfter(last);
      end.replaceChildren(
        el('h3', { text: nx ? (appending ? 'Loading ' + short(nx.name) + '…' : 'End of ' + short(last.name)) : 'You\'re all caught up' }),
        el('p.muted', { text: appendErr ? appendErr.message : nx ? 'Up next: ' + nx.name : 'No newer free chapter yet.' }),
        appending ? el('div.spinner', { style: { margin: '6px auto' } }) : el('div.row', { style: { justifyContent: 'center' } },
          nx ? el('button.btn.primary', { onclick: () => (seamless ? appendNext() : goChapter(nx)) }, appendErr ? 'Try again' : 'Next chapter', icon('next')) : null,
          el('button.btn', { onclick: () => K.closeReader() }, 'Back to series')));
    }
    let observe = () => {};
    async function appendNext() {
      const last = segs[segs.length - 1], nx = nextAfter(last.chapter);
      if (!nx || appending || state !== s) return;
      appending = true; appendErr = null; paintEnd();
      try {
        let pages = K.localPages(`${s.provider}:${s.slug}:${nx.slug}`);
        if (!pages) pages = await K.providers[s.provider].pages(s.slug, nx.slug);
        if (state !== s) return;
        if (!pages?.length) throw new Error(short(nx.name) + ' has no pages.');
        const start = s.pages.length;
        strip.insertBefore(el('div.chdiv', el('span', { text: 'End of ' + short(last.chapter.name) }), el('b', { text: nx.name })), end);
        pages.forEach((pp, k) => { s.pages.push(pp); st.push(''); job.push(''); const im = addPage(pp, start + k); imgs.push(im); strip.insertBefore(im.parentElement, end); observe(im.parentElement); });
        segs.push({ chapter: nx, start, count: pages.length });
      } catch (e) {
        if (e.locked) { nx.locked = true; appending = false; return appendNext(); }   // paid chapter: skip to the next free one
        appendErr = e;
      } finally { appending = false; if (state === s) paintEnd(); }
    }
    paintEnd();
    if (opt.mode === 'strip') strip.append(end);

    // bottom bar
    const goNext = () => { if (!s.next) return; const g = segs.find(x => x.chapter.slug === s.next.slug); if (g) pg(g.start)?.scrollIntoView({ block: 'start' }); else goChapter(s.next); };
    const goPrev = () => { if (!s.prev) return; const g = segs.find(x => x.chapter.slug === s.prev.slug); if (g) pg(g.start)?.scrollIntoView({ block: 'start' }); else goChapter(s.prev); };
    const prevBtn = el('button.btn.icon', { title: 'Previous chapter', disabled: !s.prev, onclick: goPrev }, icon('back'));
    const nextBtn = el('button.btn.icon', { title: 'Next chapter', disabled: !s.next, onclick: goNext }, icon('next'));
    const slider = el('input', { type: 'range', min: 1, max: s.pages.length, value: startPage + 1, step: 1 });
    const pc = el('span.pc');
    const modeBtn = el('button.btn.icon', { title: opt.mode === 'strip' ? 'Switch to pages' : 'Switch to long strip', onclick: () => { saveProgress(); setReader({ mode: opt.mode === 'strip' ? 'paged' : 'strip' }); K.openReader(s.provider, s.slug, s.chapter.slug); } },
      icon(opt.mode === 'strip' ? 'pages' : 'scroll'));
    const bottom = el('div.rbar.bottom.glass',
      prevBtn, slider, pc, nextBtn,
      modeBtn,
      el('button.btn.icon', { title: 'Reader settings', onclick: () => toggleSettings() }, icon('settings')));
    if (offline) bottom.prepend(el('span.tag', { text: 'Offline' }));

    // chapter drawer
    const drawer = el('div.drawer.glass', el('div.row', { style: { marginBottom: '12px' } }, el('h3', { text: 'Chapters', style: { margin: 0, flex: 1 } }),
      el('button.btn.small.icon', { onclick: () => drawer.classList.remove('open') }, icon('x'))));
    const dlist = el('div.list');
    for (const c of s.chapters) {
      const read = K.isRead(s.provider, s.slug, c.slug);
      const row = el('div.item' + (c.slug === s.chapter.slug ? '.current' : '') + (read ? '.read' : '') + (c.locked ? '.locked' : ''),
        el('div.n', el('b', { text: c.name }), el('small', { text: c.locked ? 'Locked' : K.dl.index.has(`${s.provider}:${s.slug}:${c.slug}`) ? 'Downloaded' : K.ago(c.date) })),
        c.locked ? icon('lock') : null);
      row.dataset.slug = c.slug;
      row.onclick = () => { if (!c.locked) goChapter(c); };
      dlist.append(row);
    }
    drawer.append(dlist);

    box.replaceChildren(amb, pagesBox, topBar(), bottom, drawer);
    let fpsRaf = 0;
    if (opt.fps) {
      const meter = el('div.fps', { text: '… fps' });
      box.append(meter);
      let n = 0, t0 = performance.now(), last = t0, worst = 0;
      const tick = now => {
        if (state !== s) return;
        n++; worst = Math.max(worst, now - last); last = now;
        if (now - t0 >= 1000) { meter.textContent = `${Math.round(n * 1000 / (now - t0))} fps · slowest ${Math.round(worst)} ms`; n = 0; t0 = now; worst = 0; }
        fpsRaf = requestAnimationFrame(tick);
      };
      fpsRaf = requestAnimationFrame(tick);
    }
    setTimeout(() => dlist.querySelector('.current')?.scrollIntoView({ block: 'center' }), 50);

    // show/hide bars
    let hideT;
    // Zen mode: full screen, just the pages. Bars stay away and the cursor hides when it stops moving.
    let idleT;
    const setZen = (on, quiet) => {
      box.classList.toggle('zen', on);
      if (on) { box.classList.add('hide-ui'); drawer.classList.remove('open'); box.querySelector('.rset')?.remove(); }
      else { box.classList.remove('idle'); showUi(); }
      if (K.info?.platform === 'desktop') K.api.post('/k/fullscreen', { on }).catch(() => {});
      if (!quiet) K.toast(on ? 'Zen mode · press Z or Esc to leave' : 'Zen mode off');
    };
    K.toggleZen = () => { const on = !box.classList.contains('zen'); setReader({ zen: on }); setZen(on); };
    const showUi = () => { if (box.classList.contains('zen')) return; box.classList.remove('hide-ui'); clearTimeout(hideT); hideT = setTimeout(() => { if (!box?.querySelector('.rset') && !drawer.classList.contains('open')) box?.classList.add('hide-ui'); }, 3500); };
    showUi();

    // crossing into another chapter of the strip: title, buttons, chapter list and address follow
    function switchTo(g) {
      const old = s.chapter;
      const oldSeg = segs.find(x => x.chapter === old);
      if (oldSeg && g.start > oldSeg.start) K.finishChapter(old);   // scrolled on past it
      saveProgress();
      Object.assign(s, { chapter: g.chapter, next: nextAfter(g.chapter), prev: prevBefore(g.chapter), finished: false });
      const tt = box.querySelector('.rbar.top .tt small'); if (tt) tt.textContent = g.chapter.name;
      prevBtn.disabled = !s.prev; nextBtn.disabled = !s.next;
      dlist.querySelectorAll('.item').forEach(r => r.classList.toggle('current', r.dataset.slug === g.chapter.slug));
      dlist.querySelector(`.item[data-slug="${CSS.escape(g.chapter.slug)}"]`)?.classList.add('read');
      history.replaceState(null, '', `#/read/${s.provider}/${encodeURIComponent(s.slug)}/${encodeURIComponent(g.chapter.slug)}`);
    }
    function setPage(i, fromScroll) {
      i = Math.max(0, Math.min(s.pages.length - 1, i));
      s.page = i;
      const g = segOf(i);
      if (g.chapter !== s.chapter) switchTo(g);
      const li = i - g.start;
      slider.max = g.count;
      slider.value = li + 1;
      slider.style.setProperty('--p', (g.count > 1 ? (li / (g.count - 1)) * 100 : 100) + '%');
      pc.textContent = `${li + 1} / ${g.count}`;
      paintMark();
      for (let k = i; k <= i + opt.preload; k++) load(k);
      setAmb(i);
      if (i > 0) load(i - 1);
      if (opt.mode === 'paged') {
        strip.querySelectorAll('.pg.cur').forEach(p => p.classList.remove('cur'));
        pg(i)?.classList.add('cur');
      } else if (!fromScroll) {
        pg(i)?.scrollIntoView({ block: 'start' });
      }
      saveSoon();
    }
    const saveSoon = K.debounce(saveProgress, 800);
    // Resume spot: page + how far down it. Pages get their real height as they load, so the jump is redone
    // until that page has its size, unless you start scrolling yourself first.
    let jump = opt.mode === 'strip' && (startPage > 0 || startOff > 0) ? { i: startPage, off: startOff } : null;
    const doJump = () => {
      const p = jump && pg(jump.i);
      if (!p) return;
      pagesBox.style.scrollBehavior = 'auto';
      pagesBox.scrollTop = p.offsetTop + jump.off * p.offsetHeight - pagesBox.clientHeight * 0.4;
    };
    const stopJump = () => { jump = null; };
    if (jump) {
      for (const ev of ['wheel', 'pointerdown', 'touchstart', 'keydown']) pagesBox.addEventListener(ev, stopJump, { passive: true, once: true });
      setTimeout(stopJump, 20000);
    }
    s.where = () => {
      if (opt.mode !== 'strip') return 0;
      if (jump && jump.i === s.page) return jump.off;
      const p = pg(s.page);
      if (!p || !p.offsetHeight) return 0;
      return Math.max(0, Math.min(0.999, (pagesBox.scrollTop + pagesBox.clientHeight * 0.4 - p.offsetTop) / p.offsetHeight));
    };

    if (opt.mode === 'strip') {
      // the page whose top passed the middle of the screen is the current page
      // Pages start loading well before you reach them.
      const io = new IntersectionObserver(entries => {
        for (const e of entries) if (e.isIntersecting) load(Number(e.target.dataset.i));
      }, { root: pagesBox, rootMargin: '3000px 0px' });
      // The current page is the one crossing a line 40% down the screen. The browser tracks this off the
      // main thread, so scrolling never stops to measure the page (that caused the stutter).
      const line = new IntersectionObserver(entries => {
        for (const e of entries) if (e.isIntersecting) { const i = Number(e.target.dataset.i); if (i !== s.page) setPage(i, true); }
      }, { root: pagesBox, rootMargin: '-40% 0px -59.5% 0px' });
      // far away (above or below): free the picture; its space stays so nothing jumps
      const far = new IntersectionObserver(entries => {
        for (const e of entries) if (!e.isIntersecting) unload(Number(e.target.dataset.i));
      }, { root: pagesBox, rootMargin: '9000px 0px' });
      const atEnd = new IntersectionObserver(es => {
        if (!es[0].isIntersecting || jump) return;
        if (seamless && nextAfter(segs[segs.length - 1].chapter)) return;   // the next chapter is joining underneath
        s.page = s.pages.length - 1; s.finished = true; saveProgress();
      }, { root: pagesBox });
      const nearEnd = new IntersectionObserver(es => { if (es[0].isIntersecting && seamless && !jump) appendNext(); }, { root: pagesBox, rootMargin: '0px 0px 2500px 0px' });
      observe = p => { io.observe(p); line.observe(p); far.observe(p); };
      [...strip.querySelectorAll('.pg')].forEach(observe);
      atEnd.observe(end); nearEnd.observe(end);
      let lastY = 0, ticking = false;
      pagesBox.addEventListener('scroll', () => {
        if (ticking) return;
        ticking = true;
        requestAnimationFrame(() => { ticking = false; const y = pagesBox.scrollTop; if (Math.abs(y - lastY) > 80) { if (y > lastY && !box?.classList.contains('hide-ui')) box?.classList.add('hide-ui'); lastY = y; } });
      }, { passive: true });
      s.cleanup = () => { io.disconnect(); line.disconnect(); far.disconnect(); atEnd.disconnect(); nearEnd.disconnect(); for (const b of ambCache.values()) b?.close?.(); files.clear(); st.fill(''); strip.querySelectorAll('.pg').forEach(w => { if (job[Number(w.dataset.i)]) freeSlices(w); }); };
    }

    // Auto-scroll: the strip glides down by itself (in page mode, pages turn by themselves).
    // A small pop-up holds play/pause and the speed. Scrolling yourself just holds it for a moment.
    const SPEEDS = [15, 25, 40, 60, 90, 130, 180, 250, 350, 500, 700];
    const SECS = [3, 4, 5, 6, 8, 10, 12, 15, 20, 30, 45, 60];
    let autoOn = false, autoShown = false, autoRaf = 0, autoLast = 0, autoHold = 0, autoAcc = 0, autoT = 0;
    const isStrip = opt.mode === 'strip';
    const autoVal = el('b.av');
    const autoPlay = el('button.btn.small.icon', { title: 'Pause or play (S)', onclick: () => setAuto(!autoOn) });
    const nudge = d => {
      const o = K.readerSettings(), list = isStrip ? SPEEDS : SECS, key = isStrip ? 'autoSpeed' : 'autoSecs';
      let i = list.findIndex(v => v >= o[key]); if (i < 0) i = list.length - 1;
      const dir = isStrip ? d : -d;   // "faster" means fewer seconds per page
      const v = list[Math.max(0, Math.min(list.length - 1, i + dir))];
      setReader({ [key]: v }); paintAuto();
    };
    const grip = el('span.grip', { title: 'Drag to move' }, icon('grip'));
    const pop = el('div.autopop.glass', grip, autoPlay,
      el('button.btn.small.icon', { title: 'Slower', onclick: () => nudge(-1) }, icon('minus')),
      el('div.avw', autoVal, el('small', { text: isStrip ? 'speed' : 'per page' })),
      el('button.btn.small.icon', { title: 'Faster', onclick: () => nudge(1) }, icon('plus')),
      el('button.btn.small.icon', { title: 'Turn auto-scroll off', onclick: () => { autoKeep = false; showAuto(false); } }, icon('x')));
    // Drag the grip to put the pop-up anywhere; the spot is remembered (as a share of the screen, so it fits any size).
    const POS_KEY = 'koru-autopop';
    const placePop = () => {
      let p = null; try { p = JSON.parse(localStorage.getItem(POS_KEY) || 'null'); } catch {}
      if (!p || !box) { pop.style.left = pop.style.top = ''; pop.style.right = pop.style.bottom = ''; return; }
      const W = box.clientWidth, H = box.clientHeight, w = pop.offsetWidth || 240, h = pop.offsetHeight || 48;
      pop.style.right = pop.style.bottom = 'auto';
      pop.style.left = Math.max(6, Math.min(W - w - 6, p.x * W)) + 'px';
      pop.style.top = Math.max(6, Math.min(H - h - 6, p.y * H)) + 'px';
    };
    grip.addEventListener('pointerdown', e => {
      e.preventDefault(); e.stopPropagation();
      grip.setPointerCapture(e.pointerId);
      const r0 = pop.getBoundingClientRect(), b0 = box.getBoundingClientRect(), dx = e.clientX - r0.left, dy = e.clientY - r0.top;
      pop.classList.add('dragging');
      const move = ev => {
        const W = box.clientWidth, H = box.clientHeight;
        const x = Math.max(6, Math.min(W - r0.width - 6, ev.clientX - b0.left - dx)), y = Math.max(6, Math.min(H - r0.height - 6, ev.clientY - b0.top - dy));
        pop.style.right = pop.style.bottom = 'auto'; pop.style.left = x + 'px'; pop.style.top = y + 'px';
      };
      const up = () => {
        grip.removeEventListener('pointermove', move); grip.removeEventListener('pointerup', up); grip.removeEventListener('pointercancel', up);
        pop.classList.remove('dragging');
        const W = box.clientWidth, H = box.clientHeight;
        try { localStorage.setItem(POS_KEY, JSON.stringify({ x: pop.offsetLeft / W, y: pop.offsetTop / H })); } catch {}
      };
      grip.addEventListener('pointermove', move); grip.addEventListener('pointerup', up); grip.addEventListener('pointercancel', up);
    });
    grip.addEventListener('dblclick', () => { try { localStorage.removeItem(POS_KEY); } catch {} placePop(); });   // double-click: back to the corner
    window.addEventListener('resize', placePop);

    function paintAuto() {
      const o = K.readerSettings();
      autoVal.textContent = isStrip ? `${Math.round(o.autoSpeed / 10) / 10}×` : `${o.autoSecs}s`;
      autoVal.title = isStrip ? o.autoSpeed + ' px per second' : o.autoSecs + ' seconds per page';
      autoPlay.replaceChildren(icon(autoOn ? 'pause' : 'play'));
      pop.classList.toggle('paused', !autoOn);
      box.querySelector('.autob')?.classList.toggle('on', autoShown);
    }
    function autoTick(t) {
      if (!autoOn || state !== s || !box) return;
      const dt = autoLast ? Math.min(64, t - autoLast) : 16; autoLast = t;
      if (t > autoHold) {
        const o = K.readerSettings();
        if (isStrip) {
          autoAcc += o.autoSpeed * dt / 1000;
          if (autoAcc >= 1) {
            const px = Math.floor(autoAcc); autoAcc -= px;
            const before = pagesBox.scrollTop;
            pagesBox.scrollTop = before + px;
            if (pagesBox.scrollTop === before && before > 0) {   // reached the bottom
              if (appending || (seamless && nextAfter(segs[segs.length - 1].chapter) && !appendErr)) { autoHold = performance.now() + 600; appendNext(); }
              else { setAuto(false); K.toast('End of the chapter'); return; }
            }
          }
        } else if ((autoT += dt) >= o.autoSecs * 1000) {
          autoT = 0;
          if (s.page >= s.pages.length - 1) { setAuto(false); step(1); return; }
          step(1);
        }
      }
      autoRaf = requestAnimationFrame(autoTick);
    }
    function setAuto(on) {
      autoOn = on; autoLast = 0; autoAcc = 0; autoT = 0; cancelAnimationFrame(autoRaf);
      if (on) { stopJump?.(); autoRaf = requestAnimationFrame(autoTick); }
      paintAuto();
    }
    function showAuto(on) {
      autoShown = on;
      if (on) { autoKeep = true; if (!pop.isConnected) { box.append(pop); placePop(); } setAuto(true); K.toast('Auto-scroll on · S to pause', 'ok'); }
      else { setAuto(false); pop.remove(); }
      paintAuto();
    }
    K.toggleAuto = () => { if (!autoShown) showAuto(true); else setAuto(!autoOn); };
    // your own scrolling, dragging or keys hold it briefly instead of fighting you
    const hold = () => { autoHold = performance.now() + 1400; autoAcc = 0; };
    for (const ev of ['wheel', 'touchstart', 'pointerdown']) pagesBox.addEventListener(ev, hold, { passive: true });
    if (opt.autoStart || autoKeep) setTimeout(() => { if (state === s) showAuto(true); }, 900);

    // Reading time for Stats: only while you're actually reading (you scrolled, tapped or pressed a key in the
    // last minute, or auto-scroll is running) and Koru is on screen.
    let lastAct = performance.now();
    const act = () => { lastAct = performance.now(); };
    for (const ev of ['scroll', 'wheel', 'pointerdown', 'touchstart']) pagesBox.addEventListener(ev, act, { passive: true });
    document.addEventListener('keydown', act);
    const statT = setInterval(() => {
      if (state !== s || document.hidden) return;
      if (performance.now() - lastAct < 60000 || autoOn) K.stats.add(s, 5000);
    }, 5000);

    slider.oninput = () => setPage(segOf(s.page).start + Number(slider.value) - 1);
    const step = d => {
      if (opt.mode === 'paged') {
        const n = s.page + d;
        if (n >= s.pages.length) { s.page = s.pages.length - 1; s.finished = true; saveProgress(); if (s.next && opt.autoNext) goChapter(s.next); else box.append(end); return; }
        setPage(n);
      } else pagesBox.scrollBy({ top: d * pagesBox.clientHeight * 0.85, behavior: 'smooth' });
    };
    pagesBox.addEventListener('click', e => {
      if (e.target.closest('.endcard, .ph')) return;
      const x = e.clientX / window.innerWidth;
      if (opt.tapZones && x < 0.3) { step(opt.rtl && opt.mode === 'paged' ? 1 : -1); return; }
      if (opt.tapZones && x > 0.7) { step(opt.rtl && opt.mode === 'paged' ? -1 : 1); return; }
      if (box.classList.contains('zen')) return;
      box.classList.contains('hide-ui') ? showUi() : box.classList.add('hide-ui');
    });
    box.addEventListener('pointermove', e => {
      if (box.classList.contains('zen')) { box.classList.remove('idle'); clearTimeout(idleT); idleT = setTimeout(() => box?.classList.add('idle'), 1500); return; }
      if (e.target.closest?.('.autopop')) return;   // using the auto-scroll pop-up doesn't bring the bars up
      if (e.clientY < 90 || e.clientY > window.innerHeight - 90) showUi();
    });
    const onKey = e => {
      if (!box || e.target.matches?.('input, select, textarea')) return;
      if (e.key === 'z' || e.key === 'Z') K.toggleZen();
      else if (e.key === 's' || e.key === 'S') K.toggleAuto();
      else if (e.key === 'Escape' && box.classList.contains('zen')) K.toggleZen();
      else if (e.key === 'Escape') { if (drawer.classList.contains('open')) drawer.classList.remove('open'); else K.closeReader(); }
      else if (e.key === 'ArrowRight' || e.key === 'd') step(opt.rtl && opt.mode === 'paged' ? -1 : 1);
      else if (e.key === 'ArrowLeft' || e.key === 'a') step(opt.rtl && opt.mode === 'paged' ? 1 : -1);
      else if (e.key === ' ' || e.key === 'PageDown') { e.preventDefault(); step(e.shiftKey ? -1 : 1); }
      else if (e.key === 'n' && s.next) goNext();
      else if (e.key === 'p' && s.prev) goPrev();
      else return;
    };
    document.addEventListener('keydown', onKey);
    const oldCleanup = s.cleanup;
    s.cleanup = () => { oldCleanup?.(); document.removeEventListener('keydown', onKey); clearTimeout(hideT); clearTimeout(idleT); cancelAnimationFrame(fpsRaf); cancelAnimationFrame(autoRaf); clearInterval(statT); window.removeEventListener('resize', placePop); document.removeEventListener('keydown', act); };

    // reader settings popover
    function toggleSettings() {
      const open = box.querySelector('.rset');
      if (open) { open.remove(); return; }
      const o = K.readerSettings();
      const re = patch => { saveProgress(); setReader(patch); K.openReader(s.provider, s.slug, s.chapter.slug); };
      const range = (label, key, min, max, stepv, unit) => {
        const v = el('span.val', { text: o[key] + unit });
        const r = el('input', { type: 'range', min, max, step: stepv, value: o[key] });
        const paint = () => r.style.setProperty('--p', ((r.value - min) / (max - min)) * 100 + '%');
        paint();
        r.oninput = () => { v.textContent = r.value + unit; paint(); if (key === 'width') strip.style.maxWidth = r.value + 'px'; if (key === 'gap') strip.style.gap = r.value + 'px'; };
        r.onchange = () => setReader({ [key]: Number(r.value) });
        return el('div.ctl', el('div.lab', { text: label }), r, v);
      };
      const ambRange = (label, key, min, max, stepv, unit) => {
        const n = range(label, key, min, max, stepv, unit), r = n.querySelector('input');
        r.addEventListener('input', () => applyAmb({ ...K.readerSettings(), [key]: Number(r.value) }));
        return n;
      };
      const tog = (label, key, sub, reload) => {
        const t = el('button.toggle' + (o[key] ? '.on' : ''));
        t.onclick = () => { const v = !K.readerSettings()[key]; t.classList.toggle('on', v); if (reload) re({ [key]: v }); else setReader({ [key]: v }); };
        return el('div.ctl', el('div.lab', label, sub ? el('small', { text: sub }) : null), t);
      };
      box.append(el('div.rset.glass',
        el('div.ctl', el('div.lab', { text: 'Layout' }), K.segmented([['strip', 'Strip', 'scroll'], ['paged', 'Pages', 'pages']], o.mode, v => re({ mode: v }))),
        range('Page width', 'width', 400, 1600, 20, 'px'),
        range('Gap between pages', 'gap', 0, 40, 1, 'px'),
        range('Pages to load ahead', 'preload', 1, 10, 1, ''),
        el('div.ctl', el('div.lab', 'Auto-scroll', el('small', { text: 'Hands-free reading with a speed pop-up. Key: S' })),
          el('button.btn.small', { onclick: () => { box.querySelector('.rset')?.remove(); K.toggleAuto(); } }, icon('auto'), 'Start')),
        tog('Start auto-scroll on every chapter', 'autoStart', ''),
        tog('Ambient light', 'ambient', 'A soft glow from the page around it', true),
        ambRange('Ambient strength', 'ambStrength', 0, 100, 1, '%'),
        ambRange('Ambient softness', 'ambBlur', 20, 220, 5, 'px'),
        tog('Right to left', 'rtl', 'For manga in page mode', true),
        tog('Keep reading into the next chapter', 'autoNext', 'Long strip: the next chapter joins underneath. Pages: goes on after the last page', true),
        tog('Tap sides to turn', 'tapZones', ''),
        el('div.ctl', el('div.lab', 'Zen mode', el('small', { text: 'Full screen, just the pages. Z or Esc to leave' })),
          el('button.btn.small', { onclick: () => K.toggleZen() }, icon('zen'), 'Enter')),
        tog('Show frame rate', 'fps', 'A small meter in the corner, to check for lag', true)));
    }

    pagesBox.focus();
    // already full screen = moving to the next chapter, so no hint again
    if (opt.zen) setZen(true, window.innerHeight >= screen.height - 2);
    setPage(startPage);
    if (jump) { doJump(); setTimeout(doJump, 60); }
  }
})();
